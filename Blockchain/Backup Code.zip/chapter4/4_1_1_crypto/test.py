# -*- coding: utf-8 -*-
import random
import ecdsa
seed = ''.join(random.sample('abcdefghijklmnopqrstuvwxyz!@#$%^&*()', 32)).encode()
#   2. 生成私钥
private_key = ecdsa.SigningKey.from_string(seed, curve=ecdsa.SECP256k1).to_pem()
#   3. 生成公钥
public_key = ecdsa.SigningKey.from_pem(private_key).verifying_key.to_pem()
print(f' {private_key}')
print(f' {public_key}')

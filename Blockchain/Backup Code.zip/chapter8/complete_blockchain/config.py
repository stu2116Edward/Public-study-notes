# -*- coding: utf-8 -*-
# File : config.py
# Author: taoyahui
# Date : 2022/4/28

# 设置工作量证明算法执行间隔时间
pow_interval_seconds = 20
# 设置询问最新版本区块间隔时间
version_req_interval_seconds = 20
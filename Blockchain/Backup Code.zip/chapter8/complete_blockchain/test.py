# -*- coding: utf-8 -*-
# File : test.py
# Author: taoyahui
# Date : 2022/4/29
class t():
    def __init__(self):
        id = 1

    def __init__(self, id):
        id = id

t1 = t()
t2 = t(2)
print(t(1))

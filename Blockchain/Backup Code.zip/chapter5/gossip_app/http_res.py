# -*- coding: utf-8 -*-
# File : http_res.py
# Author: taoyahui
# Date : 2022/4/1

# HTTP响应
empty_res = {'code': 404, 'data': 'empty data'}  # 空数据响应
success_res = {'code': 200, 'data': 'ok'}  # 成功响应



# -*- coding: utf-8 -*-
# File : demo_client.py
# Author: taoyahui
# Date : 2022/3/30
import socketio
import time
sio = socketio.Client()
sio.connect('http://localhost:5000')

for i in range(0,10):
    sio.emit("message", 'hello, this is client')
    time.sleep(1)

sio.disconnect()

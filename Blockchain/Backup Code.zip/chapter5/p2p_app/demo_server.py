# -*- coding: utf-8 -*-
# File : demo_server.py
# Author: taoyahui
# Date : 2022/3/30

from flask import Flask,request
import flask_socketio
app = Flask(__name__)

# 定义变量名为my_socketio防止重名
# cors_allowed_origins='*' 配置内容表示允许跨域
my_socketio = flask_socketio.SocketIO(app, cors_allowed_origins='*')

# 创建以"message"为标识的socket接口
@my_socketio.on('message')
def message(message):
    print(f"receive message : {message}")


if __name__ == '__main__':
    # 如下host表示所有ip均可访问接口
    my_socketio.run(app, host='0.0.0.0', port=5000, debug=True)

# 区块链中节点间的通信
### 区块链网络的基本概念
### 练习：绘制区块链网络(python networkx)
### P2P通信
#### 讲一下socket
### 练习: 基于socket实现节点间的通信
### 典型区块链通信协议介绍(Tendermint, Gossip)
### 
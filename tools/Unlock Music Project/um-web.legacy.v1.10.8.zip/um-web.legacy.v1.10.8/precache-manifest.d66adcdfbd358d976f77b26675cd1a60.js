self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "6fa542926314956d2206",
    "url": "css/app.5388e39c.css"
  },
  {
    "revision": "42a9696514a42affdf0a",
    "url": "css/chunk-vendors.094863c6.css"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "952702445bcc1c8d710af7af8dbfd83a",
    "url": "index.html"
  },
  {
    "revision": "ba727c068d39bc957e1da14e04868567",
    "url": "js/0.fab5c26d.worker.js"
  },
  {
    "revision": "6fa542926314956d2206",
    "url": "js/app.e0ad8f6c.js"
  },
  {
    "revision": "42a9696514a42affdf0a",
    "url": "js/chunk-vendors.0c483a87.js"
  },
  {
    "revision": "02995355b96ddf2519cd49f8aa73bb46",
    "url": "loader.js"
  },
  {
    "revision": "cd1d395410107c66b4534ec93f0073d3",
    "url": "web-manifest.json"
  }
]);
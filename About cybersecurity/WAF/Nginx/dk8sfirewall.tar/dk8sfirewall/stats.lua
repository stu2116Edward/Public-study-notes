ngx.header.content_type = "text/html; charset=utf-8"

-- 字节转换（保持不变）
local function human_bytes(n)
    if not n then return "0 B" end
    if n < 1024 then return string.format("%d B", n) end
    if n < 1024 * 1024 then return string.format("%.2f KB", n / 1024) end
    if n < 1024 * 1024 * 1024 then return string.format("%.2f MB", n / (1024 * 1024)) end
    return string.format("%.2f GB", n / (1024 * 1024 * 1024))
end

-- 耗时转换（统一显示微秒，不自动转换单位）
-- 输入：微秒（整数），输出：X μs
local function human_duration(us)
    if not us then return "0 μs" end
    return string.format("%d μs", us)  -- 直接显示微秒值
end

-- 获取限制阈值（转换为微秒级）
local function get_limits(during)
    if during == "hour" then
        return {
            count = ngx.var.limit_count_per_hour,
            bytes = ngx.var.limit_bytes_per_hour,
            costs_us = tonumber(ngx.var.limit_costs_per_hour) * 1000  -- ms → μs
        }
    else -- day
        return {
            count = ngx.var.limit_count_per_day,
            bytes = ngx.var.limit_bytes_per_day,
            costs_us = tonumber(ngx.var.limit_costs_per_day) * 1000  -- ms → μs
        }
    end
end

-- 生成表格数据行（微秒级精度）
local function generate_table_rows()
    local rows = ""
    local timestamp = ngx.now()
    local dict = ngx.shared.traffic_stats
    
    local function stats(during)
        local limits = get_limits(during)
        local bytes_limit_human = human_bytes(tonumber(limits.bytes))
        local costs_limit_human = human_duration(limits.costs_us)  -- 限制值也转为微秒显示
        
        for _, val in pairs(dict:get_keys(0)) do
            local match = "last:"..during
            if val:sub(1, #match) == match then
                local ip = val:sub(#match + 2)
                local last_time = dict:get(val) or timestamp
                local age = math.floor(timestamp - last_time)
                local count = dict:get("count:"..during..":"..ip) or 0
                local bytes = dict:get("bytes:"..during..":"..ip) or 0
                local bytes_human = human_bytes(bytes)
                -- 从共享内存读取微秒级耗时
                local costs_us = dict:get("costs:"..during..":"..ip) or 0
                local costs_human = human_duration(costs_us)  -- 统一显示微秒
                local forbidden = tostring(dict:get("forbidden:"..during..":"..ip) or false)
                
                rows = rows .. string.format([[
                    <tr>
                        <td>%s</td>
                        <td>%s</td>
                        <td>%d</td>
                        <td>%d/%s</td>
                        <td>%s/%s</td>
                        <td>%s/%s</td>
                        <td>%s</td>
                    </tr>
                ]], 
                ip, during, age, 
                count, limits.count, 
                bytes_human, bytes_limit_human, 
                costs_human, costs_limit_human, 
                forbidden
                )
            end
        end
    end
    
    stats("hour")
    stats("day")
    return rows
end

local request_type = ngx.var.arg_type or "page"

if request_type == "data" then
    ngx.say(generate_table_rows())
else
    ngx.say([[
    <html>
    <head>
    <title>IP 限制与使用统计（统一显示微秒）</title>
    <style>
        table { 
            border-collapse: collapse; 
            font-family: monospace;
            font-size: 14px;
            margin: 20px auto;
            width: 90%;
            max-width: 1500px;
        }
        th, td { 
            border: 1px solid #ccc; 
            padding: 8px 12px; 
            text-align: center;
        }
        th { 
            background: #f5f5f5; 
            font-weight: bold;
        }
        .update-time {
            text-align: center;
            margin-top: 10px;
            color: #666;
            font-size: 12px;
        }
    </style>
    <script>
        setInterval(() => {
            fetch('/dk8s.stats?type=data&t=' + Date.now())
                .then(r => r.text())
                .then(data => {
                    document.getElementById('stats-body').innerHTML = data;
                    document.getElementById('last-update').textContent = new Date().toLocaleString();
                });
        }, 500);
    </script>
    </head>
    <body>
        <table>
            <thead>
                <tr>
                    <th>IP</th>
                    <th>周期</th>
                    <th>活跃时间(秒)</th>
                    <th>请求数(当前/限制)</th>
                    <th>流量(当前/限制)</th>
                    <th>耗时(当前/限制)</th>
                    <th>是否封禁</th>
                </tr>
            </thead>
            <tbody id="stats-body">
                ]] .. generate_table_rows() .. [[
            </tbody>
        </table>
        <div class="update-time">
            最后更新: <span id="last-update">]] .. os.date("%Y-%m-%d %H:%M:%S") .. [[</span>
        </div>
    </body>
    </html>
    ]])
end
